<?php
/*
Plugin Name: Wordfence Security
Plugin URI: http://www.wordfence.com/
Description: Wordfence Security - Anti-virus, Firewall and Malware Scan
Author: Wordfence
Version: 7.5.4
Author URI: http://www.wordfence.com/
Text Domain: wordfence
Domain Path: /languages
Network: true
*/
require_once(dirname(__FILE__) . '/wordfence.php');