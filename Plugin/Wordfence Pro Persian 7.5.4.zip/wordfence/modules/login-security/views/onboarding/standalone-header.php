<?php
if (!defined('WORDFENCE_LS_VERSION')) { exit; }
/**
 * Presents the fresh install plugin header for standalone installations.
 */
?>

<script type="application/javascript">
	(function($) {
		$(function() {
			$('#wfls-onboarding-standalone-modal-dismiss').on('click', function(e) {
				e.preventDefault();
				e.stopPropagation();

				$('#wfls-onboarding-standalone-modal').slideUp(400, function() {
					$('#wfls-onboarding-standalone-modal').remove();
				});
				
				WFLS.setOptions({'dismissed-fresh-install-modal': true});
			});
		});
	})(jQuery);
</script>
