﻿=== goftino ===
Contributors: goftino
Donate link: https://www.goftino.com/contact
Tags: online chat, chat, farsi chat, goftino, online support, free chat, web chat
Requires at least: 3.6
Tested up to: 5.7.2
Stable tag: 5.3.2
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

goftino widget for wordpress users.

== Description ==

Goftino is an online chat service for web users with many features.
To use this plugin, you must register to goftino.com and enter your goftinoID in the plugin page.
More information : https://www.goftino.com/help
Contact page : https://www.goftino.com/contact
website : https://www.goftino.com


== Installation ==

to install the plugin use these steps.

1. Upload the plugin files to the `/wp-content/plugins` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Click on Goftino link on the rightside menu to configure the plugin.
4. Enter your goftinoID from the page in the Goftino admin panel (https://www.goftino.com/app/widget)
5. Save the settings then you can see Goftino widget on your webpages.

== Screenshots ==

1. Preview of Goftino setting page

== Changelog ==

= 1.0 =
First release of plugin
= 1.1 =
Compatible with WP 5
= 1.2 =
Fix an alert
= 1.3 =
change Widget Code
= 1.4 =
Optimization of load speed

== Upgrade Notice ==

= 1.0 =
First release of plugin
= 1.1 =
Compatible with WP 5
= 1.2 =
Fix an alert
= 1.3 =
change Widget Code
= 1.4 =
Optimization of load speed
